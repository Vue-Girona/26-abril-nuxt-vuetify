<template>
  <v-container>
    <v-row>
      <v-col cols="12">
        Hello. Things are looking good bro!
      </v-col>
    </v-row>
  </v-container>
</template>
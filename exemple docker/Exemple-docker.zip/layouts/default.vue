<template>
  <v-app>
    <v-main>
      <nuxt>
      </nuxt>
    </v-main>
  </v-app>
</template>